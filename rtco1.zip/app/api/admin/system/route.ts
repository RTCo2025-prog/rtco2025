import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

async function initSystemGovernanceTables() {
  try {
    // 1. جدول سجل التدقيق والرقابة غير القابل للتعديل
    await query(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_name VARCHAR(150),
        user_role VARCHAR(100),
        action_type VARCHAR(50) NOT NULL,
        sector VARCHAR(50) NOT NULL,
        description TEXT NOT NULL,
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 2. جدول الفترات المالية المقفلة
    await query(`
      CREATE TABLE IF NOT EXISTS closed_financial_periods (
        period_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        period_month VARCHAR(10) UNIQUE NOT NULL,
        closed_by VARCHAR(150),
        closure_notes TEXT,
        closed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
  } catch (e) {
    console.error("Init Governance Tables Error:", e);
  }
}

// جلب سجل الرقابة والفترات المالية المقفلة
export async function GET(req: Request) {
  try {
    await initSystemGovernanceTables();
    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action');

    // تصدير النسخة الاحتياطية لكافة جداول المنظومة بتنسيق JSON
    if (action === 'BACKUP_DATABASE') {
      const [vouchersRes, projectsRes, itemsRes, fleetRes, hrRes, logsRes] = await Promise.all([
        query(`SELECT * FROM vouchers ORDER BY created_at DESC`),
        query(`SELECT * FROM projects ORDER BY created_at DESC`),
        query(`SELECT * FROM inventory_items ORDER BY created_at DESC`),
        query(`SELECT * FROM fleet_vehicles ORDER BY created_at DESC`),
        query(`SELECT * FROM hr_employees ORDER BY created_at DESC`),
        query(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500`)
      ]);

      const backupData = {
        metadata: {
          company: "شركة البرج المتألق للمقاولات والتجارة العامة",
          exported_at: new Date().toISOString(),
          version: "ERP v2.5 Enterprise"
        },
        vouchers: vouchersRes.rows || [],
        projects: projectsRes.rows || [],
        inventory: itemsRes.rows || [],
        fleet: fleetRes.rows || [],
        employees: hrRes.rows || [],
        audit_logs: logsRes.rows || []
      };

      return new Response(JSON.stringify(backupData, null, 2), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="rtco_backup_${new Date().toISOString().slice(0, 10)}.json"`
        }
      });
    }

    const [auditRes, periodsRes] = await Promise.all([
      query(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 150`),
      query(`SELECT * FROM closed_financial_periods ORDER BY period_month DESC`)
    ]);

    return NextResponse.json({
      success: true,
      auditLogs: auditRes.rows || [],
      closedPeriods: periodsRes.rows || []
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// قيد عملية تدقيق جديدة أو إقفال/فتح فترة مالية
export async function POST(req: Request) {
  try {
    await initSystemGovernanceTables();
    const body = await req.json();
    const { action } = body;

    // 1. تسجيل قيد تدقيق رقابي
    if (action === 'RECORD_AUDIT') {
      const { user_name, user_role, action_type, sector, description, metadata } = body;
      const res = await query(`
        INSERT INTO audit_logs (user_name, user_role, action_type, sector, description, metadata)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `, [user_name || 'النظام', user_role || 'ADMIN', action_type, sector, description, JSON.stringify(metadata || {})]);

      return NextResponse.json({ success: true, log: res.rows[0] });
    }

    // 2. إقفال فترة مالية (منع التعديل نهائياً)
    if (action === 'CLOSE_PERIOD') {
      const { period_month, closed_by, closure_notes } = body;
      const res = await query(`
        INSERT INTO closed_financial_periods (period_month, closed_by, closure_notes)
        VALUES ($1, $2, $3)
        ON CONFLICT (period_month) DO UPDATE SET
          closed_by = EXCLUDED.closed_by,
          closure_notes = EXCLUDED.closure_notes,
          closed_at = CURRENT_TIMESTAMP
        RETURNING *
      `, [period_month, closed_by || 'الإدارة العليا', closure_notes || 'إقفال شهري معتمد ومطابق للحسابات']);

      // قيد الحدث في سجل التدقيق
      await query(`
        INSERT INTO audit_logs (user_name, user_role, action_type, sector, description)
        VALUES ($1, 'ADMIN', 'LOCK', 'FINANCE', $2)
      `, [closed_by || 'الإدارة العليا', `تم إقفال الفترة المالية لشهر (${period_month}) نهائياً`]);

      return NextResponse.json({ success: true, period: res.rows[0] });
    }

    // 3. إعادة فتح فترة مالية مقفلة
    if (action === 'REOPEN_PERIOD') {
      const { period_month, opened_by, reason } = body;
      await query(`DELETE FROM closed_financial_periods WHERE period_month = $1`, [period_month]);

      await query(`
        INSERT INTO audit_logs (user_name, user_role, action_type, sector, description)
        VALUES ($1, 'ADMIN', 'UNLOCK', 'FINANCE', $2)
      `, [opened_by || 'الإدارة العليا', `إعادة فتح الفترة المالية لشهر (${period_month}) - السبب: ${reason || 'مراجعة استثنائية'}`]);

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'إجراء غير معروف' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}