import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

async function initNotificationsTable() {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS system_notifications (
        notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        sector VARCHAR(50) NOT NULL, -- 'ADMIN_DOCS', 'CONTRACTS', 'INSTALLMENTS', 'FINANCE', 'PROJECTS', 'INVENTORY', 'FLEET', 'HR'
        action_type VARCHAR(50) DEFAULT 'ADD', -- 'ADD', 'UPDATE', 'DELETE'
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        link VARCHAR(255) DEFAULT '/',
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
  } catch (e) {
    console.error("Init Notifications Table Error:", e);
  }
}

export async function GET() {
  try {
    await initNotificationsTable();
    const res = await query(`
      SELECT * FROM system_notifications 
      ORDER BY created_at DESC 
      LIMIT 100
    `);
    const notifications = res.rows || [];
    const unreadCount = notifications.filter(n => !n.is_read).length;

    return NextResponse.json({
      success: true,
      notifications,
      unreadCount
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await initNotificationsTable();
    const body = await req.json();
    const { action } = body;

    // 1. تمييز الإشعار كمقروء
    if (action === 'MARK_AS_READ') {
      const { notification_id } = body;
      if (notification_id) {
        await query(
          `UPDATE system_notifications SET is_read = TRUE WHERE notification_id = $1`,
          [notification_id]
        );
      } else {
        await query(`UPDATE system_notifications SET is_read = TRUE`);
      }
      return NextResponse.json({ success: true });
    }

    // 2. إضافة إشعار جديد (سواء جاء عبر action: 'ADD_NOTIFICATION' أو مباشرة)
    const title = body.title || 'إشعار جديد في المنظومة';
    const message = body.message || '';
    const sector = body.sector || 'ADMIN_DOCS';
    const link = body.link || '/';
    const action_type = body.action_type || (action === 'ADD_NOTIFICATION' ? 'ADD' : 'ADD');

    const res = await query(`
      INSERT INTO system_notifications (sector, action_type, title, message, link)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `, [sector, action_type, title, message, link]);

    return NextResponse.json({ success: true, notification: res.rows[0] });
  } catch (err: any) {
    console.error("Notifications API Error:", err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    await query(`DELETE FROM system_notifications`);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}