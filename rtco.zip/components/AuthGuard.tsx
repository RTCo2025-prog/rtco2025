'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ShieldAlert, Loader2 } from 'lucide-react';

interface AuthGuardProps {
  children: React.ReactNode;
  allowedRoles?: ('ADMIN' | 'ACCOUNTANT' | 'SITE_ENGINEER' | 'CAPTAIN')[];
}

export default function AuthGuard({ children, allowedRoles }: AuthGuardProps) {
  const router = useRouter();
  const [authorized, setAuthorized] = useState<boolean | null>(null);

  useEffect(() => {
    const rawUser = localStorage.getItem('erp_user');
    if (!rawUser) {
      router.replace('/login');
      return;
    }

    try {
      const parsed = JSON.parse(rawUser);
      const userRole = String(parsed.role || '').toUpperCase();
      
      const normalizedRole = 
        (userRole === 'ADMIN' || userRole.includes('إدارة')) ? 'ADMIN' :
        (userRole === 'ACCOUNTANT' || userRole.includes('محاسب')) ? 'ACCOUNTANT' :
        (userRole === 'CAPTAIN' || userRole.includes('كابتن')) ? 'CAPTAIN' : 'SITE_ENGINEER';

      if (allowedRoles && !allowedRoles.includes(normalizedRole)) {
        setAuthorized(false);
        const timer = setTimeout(() => {
          router.replace('/');
        }, 1800);
        return () => clearTimeout(timer);
      } else {
        setAuthorized(true);
      }
    } catch {
      router.replace('/login');
    }
  }, [router, allowedRoles]);

  if (authorized === null) {
    return (
      <div dir="rtl" className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300 gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <p className="text-xs font-semibold">جاري التحقق من الأمان وصلاحيات الحساب...</p>
      </div>
    );
  }

  if (authorized === false) {
    return (
      <div dir="rtl" className="min-h-screen bg-slate-950 flex items-center justify-center p-4 font-sans">
        <div className="bg-slate-900 border border-rose-500/30 p-8 rounded-3xl text-center max-w-md shadow-2xl space-y-4">
          <div className="w-14 h-14 bg-rose-500/10 text-rose-400 rounded-2xl flex items-center justify-center mx-auto border border-rose-500/20">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-white">منطقة محظورة!</h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            عذراً، لا تملك الصلاحية للوصول إلى هذا القسم بناءً على طبيعة حسابك الوظيفي.
          </p>
          <p className="text-[11px] text-amber-400 font-mono">جاري إعادتك للرئيسية...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}