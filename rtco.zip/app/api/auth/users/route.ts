import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

async function initUsersTable() {
  await query(`
    CREATE TABLE IF NOT EXISTS system_users (
      user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      username VARCHAR(100) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      full_name VARCHAR(150) NOT NULL,
      job_title VARCHAR(150) DEFAULT 'موظف',
      is_super_admin BOOLEAN DEFAULT FALSE,
      status VARCHAR(50) DEFAULT 'ACTIVE',
      permissions JSONB DEFAULT '{}',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // إنشاء حساب المدير المفوض الافتراضي إن لم يكن موجوداً
  const checkAdmin = await query(`SELECT user_id FROM system_users WHERE username = 'admin'`);
  if (checkAdmin.rows.length === 0) {
    await query(`
      INSERT INTO system_users (username, password_hash, full_name, job_title, is_super_admin, status, permissions)
      VALUES (
        'admin',
        'admin123',
        'المدير المفوض',
        'المدير المفوض للشركة',
        TRUE,
        'ACTIVE',
        '{"all": {"view": true, "add": true, "edit": true, "delete": true}}'
      )
    `);
  }
}

// جلب قائمة المستخدمين (للمدير المفوض فقط)
export async function GET() {
  try {
    await initUsersTable();
    const res = await query(`
      SELECT user_id, username, full_name, job_title, is_super_admin, status, permissions, created_at
      FROM system_users
      ORDER BY created_at DESC
    `);
    return NextResponse.json({ success: true, users: res.rows });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// إضافة أو تعديل مستخدم وتحديد صلاحياته
export async function POST(req: Request) {
  try {
    await initUsersTable();
    const body = await req.json();
    const { action } = body;

    // تسجيل الدخول
    if (action === 'LOGIN') {
      const { username, password } = body;
      const cleanUser = String(username || '').trim().toLowerCase();
      const res = await query(`
        SELECT user_id, username, password_hash, full_name, job_title, is_super_admin, status, permissions
        FROM system_users
        WHERE LOWER(username) = $1
      `, [cleanUser]);

      if (res.rows.length === 0) {
        return NextResponse.json({ error: 'اسم المستخدم غير موجود' }, { status: 401 });
      }

      const user = res.rows[0];
      if (user.status !== 'ACTIVE') {
        return NextResponse.json({ error: 'هذا الحساب موقوف من قبل المدير المفوض' }, { status: 403 });
      }

      // مطابقة كلمة المرور
      if (user.password_hash !== password) {
        return NextResponse.json({ error: 'كلمة المرور غير صحيحة' }, { status: 401 });
      }

      const { password_hash, ...safeUser } = user;
      return NextResponse.json({ success: true, user: safeUser });
    }

    // إنشاء حساب مستخدم جديد وتحديد الصلاحيات
    if (action === 'CREATE_USER') {
      const { username, password, full_name, job_title, permissions } = body;
      const cleanUser = String(username || '').trim().toLowerCase();

      const exist = await query(`SELECT user_id FROM system_users WHERE LOWER(username) = $1`, [cleanUser]);
      if (exist.rows.length > 0) {
        return NextResponse.json({ error: 'اسم المستخدم مسجل مسبقاً' }, { status: 400 });
      }

      const res = await query(`
        INSERT INTO system_users (username, password_hash, full_name, job_title, is_super_admin, status, permissions)
        VALUES ($1, $2, $3, $4, FALSE, 'ACTIVE', $5)
        RETURNING user_id, username, full_name, job_title, is_super_admin, status, permissions
      `, [cleanUser, password, full_name, job_title || 'موظف', JSON.stringify(permissions || {})]);

      return NextResponse.json({ success: true, user: res.rows[0] });
    }

    // تحديث حساب وصلاحيات مستخدم
    if (action === 'UPDATE_USER') {
      const { user_id, full_name, job_title, password, status, permissions } = body;

      let q = `
        UPDATE system_users
        SET full_name = $1,
            job_title = $2,
            status = $3,
            permissions = $4
      `;
      const params = [full_name, job_title, status || 'ACTIVE', JSON.stringify(permissions || {})];

      if (password && String(password).trim().length > 0) {
        q += `, password_hash = $5 WHERE user_id = $6 RETURNING user_id, username, full_name, job_title, is_super_admin, status, permissions`;
        params.push(password, user_id);
      } else {
        q += ` WHERE user_id = $5 RETURNING user_id, username, full_name, job_title, is_super_admin, status, permissions`;
        params.push(user_id);
      }

      const res = await query(q, params);
      return NextResponse.json({ success: true, user: res.rows[0] });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// حذف مستخدم
export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('id');

    if (!userId) {
      return NextResponse.json({ error: 'معرف المستخدم مطلوب' }, { status: 400 });
    }

    // منع حذف حساب المدير المفوض الأساسي
    const check = await query(`SELECT is_super_admin FROM system_users WHERE user_id = $1`, [userId]);
    if (check.rows[0]?.is_super_admin) {
      return NextResponse.json({ error: 'لا يمكن حذف حساب المدير المفوض الأساسي' }, { status: 403 });
    }

    await query(`DELETE FROM system_users WHERE user_id = $1`, [userId]);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}