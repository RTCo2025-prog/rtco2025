'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { 
  PieChart as PieChartIcon, 
  ArrowLeft, 
  Printer, 
  RefreshCw, 
  Wallet, 
  TrendingUp, 
  Truck, 
  HardHat, 
  Coins, 
  BarChart3, 
  Receipt, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Calendar, 
  RotateCcw,
  Boxes,
  Building,
  Users,
  Activity,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  CartesianGrid
} from 'recharts';
import AuthGuard from '@/components/AuthGuard';

function formatNum(val: number | string): string {
  const n = Number(val) || 0;
  return n.toLocaleString('en-US');
}

const PIE_COLORS = ['#38bdf8', '#10b981', '#f59e0b', '#a855f7', '#f43f5e'];

export default function FinancialReportsPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  
  const [projectsRaw, setProjectsRaw] = useState<any[]>([]);
  const [vouchersRaw, setVouchersRaw] = useState<any[]>([]);
  const [tripsRaw, setTripsRaw] = useState<any[]>([]);
  const [maintRaw, setMaintRaw] = useState<any[]>([]);
  const [inventoryItemsRaw, setInventoryItemsRaw] = useState<any[]>([]);
  const [inventoryTransRaw, setInventoryTransRaw] = useState<any[]>([]);
  const [employeesRaw, setEmployeesRaw] = useState<any[]>([]);
  const [payrollRunsRaw, setPayrollRunsRaw] = useState<any[]>([]);
  const [realEstateUnitsRaw, setRealEstateUnitsRaw] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [startDate, setStartDate] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
  });
  const [isAllTime, setIsAllTime] = useState(false);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [resP, resV, resF, resI, resH, resRE] = await Promise.all([
        fetch('/api/projects', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ projects: [] })),
        fetch('/api/vouchers', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ vouchers: [] })),
        fetch('/api/fleet', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ trips: [], maintenance: [] })),
        fetch('/api/inventory', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ items: [], transactions: [] })),
        fetch('/api/hr', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ employees: [], payrollRuns: [] })),
        fetch('/api/real-estate', { cache: 'no-store' }).then(r => r.json()).catch(() => ({ units: [] }))
      ]);

      if (resP.projects) setProjectsRaw(resP.projects);
      if (resV.vouchers) setVouchersRaw(resV.vouchers);
      if (resF.trips) setTripsRaw(resF.trips);
      if (resF.maintenance) setMaintRaw(resF.maintenance);
      if (resI.items) setInventoryItemsRaw(resI.items);
      if (resI.transactions) setInventoryTransRaw(resI.transactions);
      if (resH.employees) setEmployeesRaw(resH.employees);
      if (resH.payrollRuns) setPayrollRunsRaw(resH.payrollRuns);
      if (resRE.units) setRealEstateUnitsRaw(resRE.units);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const raw = localStorage.getItem('erp_user');
    if (raw) {
      try {
        setCurrentUser(JSON.parse(raw));
      } catch {}
    }
    loadAllData();
  }, []);

  const setQuickRange = (type: 'THIS_MONTH' | 'THIS_YEAR' | 'ALL') => {
    const now = new Date();
    if (type === 'THIS_MONTH') {
      setIsAllTime(false);
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(lastDay);
    } else if (type === 'THIS_YEAR') {
      setIsAllTime(false);
      const firstDay = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
      const lastDay = new Date(now.getFullYear(), 11, 31).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(lastDay);
    } else {
      setIsAllTime(true);
      setStartDate('');
      setEndDate('');
    }
  };

  const handleShiftMonth = (direction: 'PREV' | 'NEXT') => {
    setIsAllTime(false);
    let baseDate = startDate ? new Date(startDate) : new Date();
    if (isNaN(baseDate.getTime())) baseDate = new Date();

    if (direction === 'PREV') {
      baseDate.setMonth(baseDate.getMonth() - 1);
    } else {
      baseDate.setMonth(baseDate.getMonth() + 1);
    }

    const firstDay = new Date(baseDate.getFullYear(), baseDate.getMonth(), 1).toISOString().split('T')[0];
    const lastDay = new Date(baseDate.getFullYear(), baseDate.getMonth() + 1, 0).toISOString().split('T')[0];
    
    setStartDate(firstDay);
    setEndDate(lastDay);
  };

  // 1. تصفية السندات
  const filteredVouchers = useMemo(() => {
    return vouchersRaw.filter((v: any) => {
      if (v.status === 'VOID' || v.status === 'CANCELLED') return false;
      if (isAllTime) return true;
      const vDate = String(v.issue_date || v.created_at || '').split('T')[0];
      if (startDate && vDate < startDate) return false;
      if (endDate && vDate > endDate) return false;
      return true;
    });
  }, [vouchersRaw, startDate, endDate, isAllTime]);

  // 2. تصفية الأسطول
  const fleetFinance = useMemo(() => {
    const validTrips = tripsRaw.filter((t: any) => {
      if (t.trip_status !== 'COMPLETED') return false;
      if (isAllTime) return true;
      const tDate = String(t.departure_time || t.created_at || '').split('T')[0];
      if (startDate && tDate < startDate) return false;
      if (endDate && tDate > endDate) return false;
      return true;
    });

    const validMaint = maintRaw.filter((m: any) => {
      if (isAllTime) return true;
      const mDate = String(m.service_date || m.created_at || '').split('T')[0];
      if (startDate && mDate < startDate) return false;
      if (endDate && mDate > endDate) return false;
      return true;
    });

    const revenue = validTrips.reduce((acc: number, curr: any) => acc + Number(curr.trip_cost || 0), 0);
    const expenses = validMaint.reduce((acc: number, curr: any) => acc + Number(curr.cost || 0), 0);

    return { revenue, expenses, net: revenue - expenses };
  }, [tripsRaw, maintRaw, startDate, endDate, isAllTime]);

  // 3. تصفية التجارة والمخزن
  const tradeFinance = useMemo(() => {
    let salesRevenue = 0;
    let purchasesExpenses = 0;
    let costOfSoldGoods = 0;

    const validTrans = inventoryTransRaw.filter((tr: any) => {
      if (isAllTime) return true;
      const trDate = String(tr.created_at || '').split('T')[0];
      if (startDate && trDate < startDate) return false;
      if (endDate && trDate > endDate) return false;
      return true;
    });

    validTrans.forEach((tr: any) => {
      const amt = Number(tr.total_amount) || 0;
      const qty = Number(tr.quantity) || 0;

      if (tr.trans_type === 'IN') {
        purchasesExpenses += amt;
      } else if (tr.trans_type === 'OUT') {
        const isTradeSale = tr.project_name === 'بيع تجارة عامة' || 
                            tr.project_name === 'بيع تجاري خارجي' || 
                            String(tr.supplier_or_recipient || '').includes('بيع تجاري');
        if (isTradeSale) {
          salesRevenue += amt;
          const orig = inventoryItemsRaw.find((i: any) => i.item_id === tr.item_id);
          const uCost = Number(orig?.unit_cost || 0);
          costOfSoldGoods += (qty * uCost);
        }
      }
    });

    const netProfit = salesRevenue - costOfSoldGoods;

    return {
      salesRevenue,
      purchasesExpenses,
      costOfSoldGoods,
      netProfit,
      margin: salesRevenue > 0 ? ((netProfit / salesRevenue) * 100).toFixed(1) : '0'
    };
  }, [inventoryTransRaw, inventoryItemsRaw, startDate, endDate, isAllTime]);

  // 4. تصفية الرواتب
  const hrFinance = useMemo(() => {
    const activeEmployees = employeesRaw.filter((e: any) => e.status === 'ACTIVE' || !e.status);
    const monthlyPayroll = activeEmployees.reduce((acc: number, e: any) => {
      return acc + (Number(e.base_salary || 0) + Number(e.allowances || 0));
    }, 0);

    if (isAllTime) {
      return { totalSalaries: monthlyPayroll, count: activeEmployees.length, monthlyPayroll, activeMonthsCount: 1, isAverage: true };
    }

    const hasFilter = Boolean(startDate || endDate);

    if (payrollRunsRaw && payrollRunsRaw.length > 0) {
      const validRuns = payrollRunsRaw.filter((r: any) => {
        const rMonth = String(r.payroll_month || r.run_date || r.created_at || '');
        if (startDate && rMonth < startDate.substring(0, 7)) return false;
        if (endDate && rMonth > endDate.substring(0, 7)) return false;
        return true;
      });
      if (validRuns.length > 0) {
        const total = validRuns.reduce((acc: number, r: any) => acc + Number(r.net_salary || 0), 0);
        return { totalSalaries: total, count: activeEmployees.length, monthlyPayroll, activeMonthsCount: validRuns.length, isAverage: false };
      }
    }

    let companyStartYearMonth = '2024-01';
    for (const e of employeesRaw) {
      const d = String(e.hire_date || e.created_at || '').split('T')[0];
      if (d && d.length >= 7) {
        const ym = d.substring(0, 7);
        if (ym < companyStartYearMonth && ym >= '2020-01') companyStartYearMonth = ym;
      }
    }

    if (!hasFilter) {
      return { totalSalaries: monthlyPayroll, count: activeEmployees.length, monthlyPayroll, activeMonthsCount: 1, isAverage: false };
    }

    const filterStart = startDate ? startDate.substring(0, 7) : companyStartYearMonth;
    const filterEnd = endDate ? endDate.substring(0, 7) : filterStart;

    if (filterEnd < companyStartYearMonth) {
      return { totalSalaries: 0, count: activeEmployees.length, monthlyPayroll, activeMonthsCount: 0, isAverage: false };
    }

    const effectiveStart = filterStart < companyStartYearMonth ? companyStartYearMonth : filterStart;
    const effectiveEnd = filterEnd;

    if (effectiveStart > effectiveEnd) {
      return { totalSalaries: 0, count: activeEmployees.length, monthlyPayroll, activeMonthsCount: 0, isAverage: false };
    }

    const [ey1, em1] = effectiveStart.split('-').map(Number);
    const [ey2, em2] = effectiveEnd.split('-').map(Number);
    const activeMonthsCount = Math.max(1, (ey2 - ey1) * 12 + (em2 - em1) + 1);

    return {
      totalSalaries: monthlyPayroll * activeMonthsCount,
      count: activeEmployees.length,
      monthlyPayroll,
      activeMonthsCount,
      isAverage: false
    };
  }, [payrollRunsRaw, employeesRaw, startDate, endDate, isAllTime]);

  // 5. تصفية العقارات
  const realEstateFinance = useMemo(() => {
    const soldUnits = realEstateUnitsRaw.filter((u: any) => {
      if (u.status !== 'SOLD') return false;
      if (isAllTime) return true;
      const uDate = String(u.sold_at || u.updated_at || u.created_at || '').split('T')[0];
      if (startDate && uDate && uDate < startDate) return false;
      if (endDate && uDate && uDate > endDate) return false;
      return true;
    });
    const revenue = soldUnits.reduce((acc: number, u: any) => acc + Number(u.price || 0), 0);
    return { revenue, unitsCount: realEstateUnitsRaw.length, soldCount: soldUnits.length };
  }, [realEstateUnitsRaw, startDate, endDate, isAllTime]);

  // 6. المقاولات والمشاريع (المشاريع المكتملة تبقى محسوبة دائماً ضمن الحسابات)
  const projects = useMemo(() => {
    const clean = (t: string) => (t || '').trim().toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/\s+/g, ' ');

    const activeProjectsInPeriod = projectsRaw.filter((p) => {
      if (isAllTime) return true;
      const pStart = String(p.start_date || p.created_at || '').split('T')[0];
      // لا يُستبعد المشروع إلا إذا كانت الفترة المحددة تنتهي تماماً قبل بدء المشروع
      if (endDate && pStart && endDate < pStart) return false;
      return true;
    });

    return activeProjectsInPeriod.map((p) => {
      let rec = 0;
      let exp = 0;
      const pId = String(p.project_id || '');
      const pName = clean(p.project_name);

      for (const v of filteredVouchers) {
        const vProjId = String(v.project_id || '');
        const vProjName = clean(v.project_name || '');
        const vNotes = clean(v.notes || '');

        const isMatched = (vProjId !== '' && vProjId === pId) || 
                          (vProjName !== '' && (vProjName === pName || pName.includes(vProjName))) || 
                          (pName.length > 4 && vNotes.includes(pName));

        if (isMatched) {
          const val = Number(v.total_amount) || Number(v.amount) || 0;
          if (v.voucher_type === 'RECEIPT') rec += val;
          if (v.voucher_type === 'PAYMENT') exp += val;
        }
      }

      const projectPayVouchers = filteredVouchers.filter((v: any) => {
        if (v.voucher_type !== 'PAYMENT') return false;
        const vProjId = String(v.project_id || '');
        const vNotes = clean(v.notes || '');
        return (vProjId === pId) || vNotes.includes(pName);
      }).map((v: any) => {
        let vSubId = '';
        let vMatId = '';
        let vExpId = '';
        let vParty = '';
        try {
          const parsed = JSON.parse(v.notes || '{}');
          if (parsed.subcontractor_id) vSubId = String(parsed.subcontractor_id);
          if (parsed.material_id) vMatId = String(parsed.material_id);
          if (parsed.expense_id) vExpId = String(parsed.expense_id);
          if (parsed.partyAr) vParty = clean(parsed.partyAr);
        } catch {}
        return {
          ...v,
          vSubId,
          vMatId,
          vExpId,
          vParty: vParty || clean(v.party_name || ''),
          vNotesClean: clean(v.notes || ''),
          remainingAlloc: Number(v.total_amount) || Number(v.amount) || 0
        };
      });

      // المواد
      const rawMaterials = p.materials || [];
      let actualMaterialsCost = 0;
      let paidMaterialsVouchers = 0;
      for (const mat of rawMaterials) {
        const mDate = String(mat.created_at || '').split('T')[0];
        const inRange = isAllTime || ((!startDate || mDate >= startDate) && (!endDate || mDate <= endDate));
        if (inRange) {
          const recQty = Number(mat.quantity_received) || 0;
          const price = Number(mat.unit_price) || 0;
          const itemCost = recQty * price;
          actualMaterialsCost += itemCost;

          const matIdStr = String(mat.material_id || '');
          const sNameClean = clean(mat.supplier_name || '');
          let batchPaid = 0;

          for (const v of projectPayVouchers) {
            if (v.remainingAlloc <= 0) continue;
            const isMatch = (matIdStr !== '' && (v.vMatId === matIdStr || v.vNotesClean.includes(matIdStr))) ||
                            (sNameClean && sNameClean !== 'عام' && (v.vParty.includes(sNameClean) || v.vNotesClean.includes(sNameClean)));
            if (isMatch) {
              const take = Math.min(itemCost - batchPaid, v.remainingAlloc);
              batchPaid += take;
              v.remainingAlloc -= take;
              if (batchPaid >= itemCost) break;
            }
          }
          paidMaterialsVouchers += batchPaid;
        }
      }

      // مقاولو الباطن
      const rawSubs = p.subcontractors || [];
      let totalSubsContract = 0;
      let totalSubsPaidVouchers = 0;
      for (const sub of rawSubs) {
        const sDate = String(sub.created_at || p.start_date || p.created_at || '').split('T')[0];
        const inRange = isAllTime || ((!startDate || sDate >= startDate) && (!endDate || sDate <= endDate));
        
        const cVal = inRange ? (Number(sub.contract_value) || 0) : 0;
        totalSubsContract += cVal;

        const sIdStr = String(sub.subcontractor_id || '');
        const sNameKey = clean(sub.name);
        let batchPaid = 0;

        for (const v of projectPayVouchers) {
          if (v.remainingAlloc <= 0) continue;
          const isMatch = (sIdStr !== '' && (v.vSubId === sIdStr || v.vNotesClean.includes(sIdStr))) ||
                          (v.vParty === sNameKey || v.vNotesClean.includes(sNameKey));
          if (isMatch) {
            const take = Math.min(cVal > 0 ? cVal - batchPaid : v.remainingAlloc, v.remainingAlloc);
            batchPaid += take;
            v.remainingAlloc -= take;
            if (cVal > 0 && batchPaid >= cVal) break;
          }
        }
        totalSubsPaidVouchers += batchPaid;
      }

      // المصاريف التشغيلية
      const rawOperatingExp = p.operating_expenses || [];
      let totalOperatingExpCost = 0;
      let totalOperatingExpPaid = 0;
      for (const expItem of rawOperatingExp) {
        const eDate = String(expItem.created_at || p.start_date || p.created_at || '').split('T')[0];
        const inRange = isAllTime || ((!startDate || eDate >= startDate) && (!endDate || eDate <= endDate));

        const eVal = inRange ? (Number(expItem.amount) || 0) : 0;
        totalOperatingExpCost += eVal;

        const eIdStr = String(expItem.expense_id || '');
        const expNameKey = clean(expItem.title);
        let batchPaid = 0;

        for (const v of projectPayVouchers) {
          if (v.remainingAlloc <= 0) continue;
          const isMatch = (eIdStr !== '' && (v.vExpId === eIdStr || v.vNotesClean.includes(eIdStr))) ||
                          (v.vParty === expNameKey || v.vNotesClean.includes(expNameKey));
          if (isMatch) {
            const take = Math.min(eVal > 0 ? eVal - batchPaid : v.remainingAlloc, v.remainingAlloc);
            batchPaid += take;
            v.remainingAlloc -= take;
            if (eVal > 0 && batchPaid >= eVal) break;
          }
        }
        totalOperatingExpPaid += batchPaid;
      }

      // التكاليف الصافية
      const pureGeneralExpenses = Math.max(0, exp - totalSubsPaidVouchers - paidMaterialsVouchers - totalOperatingExpPaid);
      const totalSiteCosts = actualMaterialsCost + totalSubsContract + totalOperatingExpCost + pureGeneralExpenses;
      const netCash = rec - totalSiteCosts;

      return {
        ...p,
        actualReceived: rec,
        actualExpenses: totalSiteCosts,
        netCash: netCash
      };
    });
  }, [projectsRaw, filteredVouchers, startDate, endDate, isAllTime]);

  // 7. المؤشرات الكلية المجمعة
  const summary = useMemo(() => {
    const totalProjectsContract = projects.reduce((acc, p) => acc + Number(p.contract_value || 0), 0);
    const totalProjectsReceived = projects.reduce((acc, p) => acc + Number(p.actualReceived || 0), 0);
    const totalProjectsCosts = projects.reduce((acc, p) => acc + Number(p.actualExpenses || 0), 0);

    const grandTotalRevenue = totalProjectsReceived + fleetFinance.revenue + tradeFinance.salesRevenue + realEstateFinance.revenue;
    const grandTotalExpenses = totalProjectsCosts + fleetFinance.expenses + tradeFinance.purchasesExpenses + hrFinance.totalSalaries;
    
    const grandNetProfit = grandTotalRevenue - grandTotalExpenses;
    const overallMargin = grandTotalRevenue > 0 ? ((grandNetProfit / grandTotalRevenue) * 100).toFixed(1) : '0';

    return {
      grandTotalRevenue,
      grandTotalExpenses,
      grandNetProfit,
      overallMargin,
      totalProjectsContract,
      totalProjectsReceived,
      totalProjectsCosts,
      projectsCount: projects.length
    };
  }, [projects, fleetFinance, tradeFinance, hrFinance, realEstateFinance]);

  // بيانات الرسوم البيانية
  const barChartData = useMemo(() => {
    return projects.map((p) => ({
      name: p.project_name?.length > 15 ? p.project_name.substring(0, 14) + '..' : p.project_name,
      'قيمة العقد': Number(p.contract_value || 0),
      'المقبوض الفعلي': Number(p.actualReceived || 0),
      'التكاليف الفعلية': Number(p.actualExpenses || 0)
    }));
  }, [projects]);

  const revenuePieData = useMemo(() => {
    return [
      { name: 'المقاولات', value: summary.totalProjectsReceived },
      { name: 'أسطول النقل', value: fleetFinance.revenue },
      { name: 'التجارة والمخزن', value: tradeFinance.salesRevenue },
      { name: 'العقارات', value: realEstateFinance.revenue }
    ].filter(item => item.value > 0);
  }, [summary, fleetFinance, tradeFinance, realEstateFinance]);

  const expensesPieData = useMemo(() => {
    return [
      { name: 'تكاليف المقاولات', value: summary.totalProjectsCosts },
      { name: 'مصاريف الأسطول', value: fleetFinance.expenses },
      { name: 'مشتريات المخزن', value: tradeFinance.purchasesExpenses },
      { name: 'كتلة الرواتب', value: hrFinance.totalSalaries }
    ].filter(item => item.value > 0);
  }, [summary, fleetFinance, tradeFinance, hrFinance]);

  const trendAreaData = useMemo(() => {
    return projects.map((p, idx) => ({
      name: p.project_name?.length > 12 ? p.project_name.substring(0, 11) + '..' : (p.project_name || `مشروع ${idx + 1}`),
      'صافي السيولة': Number(p.netCash || 0),
      'المقبوض': Number(p.actualReceived || 0),
      'التكلفة': Number(p.actualExpenses || 0)
    }));
  }, [projects]);

  if (!currentUser) return null;

  return (
    <AuthGuard allowedRoles={['ADMIN', 'ACCOUNTANT']}>
      <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 font-sans print:bg-white print:p-0">
        
        {/* الترويسة الرئيسية */}
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between pb-6 border-b border-slate-800 gap-4 print:hidden">
          <div className="flex items-center gap-3">
            <div className="bg-sky-500 p-2.5 rounded-xl text-slate-950 font-black shadow-lg shadow-sky-500/10">
              <PieChartIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white">التقرير المالي التنفيذي وقائمة الدخل الموحدة</h1>
                <span className="bg-sky-500/20 text-sky-300 border border-sky-500/40 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                  Enterprise Analytics
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">شركة البرج المتألق - تكامل المقاولات، الأسطول، التجارة، الرواتب، والعقارات</p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-end md:self-auto">
            <button 
              onClick={loadAllData} 
              className="p-2 bg-slate-900 border border-slate-800 rounded-xl text-slate-400 hover:text-sky-400 transition" 
              title="تحديث ومزامنة البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button 
              onClick={() => window.print()} 
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-lg shadow-emerald-600/20"
            >
              <Printer className="w-4 h-4" /> طباعة التقرير (A4)
            </button>
            <Link 
              href="/vouchers" 
              className="bg-slate-900 border border-slate-800 text-purple-400 hover:bg-slate-800 px-3.5 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1.5"
            >
              <Receipt className="w-4 h-4" /> شاشة السندات
            </Link>
            <Link 
              href="/" 
              className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs hover:bg-slate-800 transition"
            >
              <ArrowLeft className="w-4 h-4" /> الرئيسية
            </Link>
          </div>
        </div>

        {/* شريط فلترة التاريخ */}
        <div className="max-w-7xl mx-auto mt-6 bg-slate-900/90 border border-slate-800 p-4 rounded-2xl print:hidden flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-wrap w-full md:w-auto">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs">
              <Calendar className="w-4 h-4" />
              <span>النطاق الزمني:</span>
            </div>

            <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-xl p-1">
              <button 
                onClick={() => handleShiftMonth('PREV')} 
                className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg transition"
                title="الشهر السابق"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <span className="px-2 text-xs font-mono text-amber-400 font-bold">تنقل شهري</span>
              <button 
                onClick={() => handleShiftMonth('NEXT')} 
                className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg transition"
                title="الشهر التالي"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">من:</span>
              <input 
                type="date" 
                value={startDate} 
                onChange={(e) => { setIsAllTime(false); setStartDate(e.target.value); }}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono outline-none focus:border-sky-500 text-xs"
              />
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">إلى:</span>
              <input 
                type="date" 
                value={endDate} 
                onChange={(e) => { setIsAllTime(false); setEndDate(e.target.value); }}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono outline-none focus:border-sky-500 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto">
            <button
              onClick={() => setQuickRange('THIS_MONTH')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition"
            >
              هذا الشهر
            </button>
            <button
              onClick={() => setQuickRange('THIS_YEAR')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition"
            >
              هذا العام
            </button>
            <button
              onClick={() => setQuickRange('ALL')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition flex items-center gap-1 ${isAllTime ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 hover:bg-slate-700 text-amber-400'}`}
            >
              <RotateCcw className="w-3.5 h-3.5" /> الكل
            </button>
          </div>
        </div>

        {/* المؤشرات المالية الموحدة */}
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden shadow-lg shadow-emerald-500/5">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs text-slate-400 font-semibold block flex items-center gap-1.5">
                  <ArrowDownLeft className="w-4 h-4 text-emerald-400" /> إجمالي إيرادات الشركة المجمعة
                </span>
                <div className="text-2xl font-black font-mono text-emerald-400 mt-2">
                  {formatNum(summary.grandTotalRevenue)} <span className="text-xs font-sans text-slate-400">د.ع</span>
                </div>
              </div>
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
                <Wallet className="w-5 h-5" />
              </div>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">المقاولات + النقل + التجارة + العقارات</p>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden shadow-lg shadow-rose-500/5">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs text-slate-400 font-semibold block flex items-center gap-1.5">
                  <ArrowUpRight className="w-4 h-4 text-rose-400" /> إجمالي المصروفات والتشغيل
                </span>
                <div className="text-2xl font-black font-mono text-rose-400 mt-2">
                  {formatNum(summary.grandTotalExpenses)} <span className="text-xs font-sans text-slate-400">د.ع</span>
                </div>
              </div>
              <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/20">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">المشاريع + الأسطول + المخزن + كتلة الرواتب</p>
          </div>

          <div className={`bg-slate-900 border p-5 rounded-2xl relative overflow-hidden shadow-lg ${summary.grandNetProfit >= 0 ? 'border-sky-500/40 bg-sky-500/5' : 'border-rose-500/40 bg-rose-500/5'}`}>
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs text-slate-300 font-semibold block flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-sky-400" /> صافي أرباح الشركة الكلي
                </span>
                <div className={`text-2xl font-black font-mono mt-2 ${summary.grandNetProfit >= 0 ? 'text-sky-400' : 'text-rose-400'}`}>
                  {formatNum(summary.grandNetProfit)} <span className="text-xs font-sans text-slate-400">د.ع</span>
                </div>
              </div>
              <div className="px-2.5 py-1 bg-sky-500/20 text-sky-300 rounded-lg text-xs font-bold font-mono">
                {summary.overallMargin}% هامش
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-2 font-sans">صافي العائد التراكمي بعد حسم كافة الالتزامات</p>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs text-slate-400 font-semibold block">
                  {hrFinance.isAverage ? 'متوسط سعر الراتب الشهري' : 'إجمالي كتلة الرواتب المنصرفة'}
                </span>
                <div className="text-2xl font-black font-mono text-rose-400 mt-2">
                  {formatNum(hrFinance.totalSalaries)} <span className="text-xs font-sans text-slate-500">د.ع</span>
                </div>
              </div>
              <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/20">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              {hrFinance.isAverage 
                ? `متوسط تكلفة ${hrFinance.count} موظفين شهرياً` 
                : (hrFinance.activeMonthsCount > 0 
                    ? `لعدد ${hrFinance.count} موظفين (${formatNum(hrFinance.monthlyPayroll)} د.ع/شهر × ${hrFinance.activeMonthsCount} أشهر)`
                    : `لعدد ${hrFinance.count} موظفين (لا توجد رواتب مستحقة بالفترة)`)}
            </p>
          </div>
        </div>

        {/* كروت المركز المالي للقطاعات الخمسة */}
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 print:hidden">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Boxes className="w-4 h-4 text-sky-400" /> التجارة والمخزن
              </h3>
              <span className="text-[10px] text-sky-400 font-mono font-bold">مبيعات</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400"><span>المبيعات:</span><strong className="text-emerald-400">{formatNum(tradeFinance.salesRevenue)}</strong></div>
              <div className="flex justify-between text-slate-400"><span>المشتريات:</span><strong className="text-rose-400">{formatNum(tradeFinance.purchasesExpenses)}</strong></div>
              <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-800"><span>الصافي:</span><strong className="text-sky-400">{formatNum(tradeFinance.netProfit)} د.ع</strong></div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-400" /> أسطول النقل
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono font-bold">لوجستيات</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400"><span>الإيراد:</span><strong className="text-emerald-400">{formatNum(fleetFinance.revenue)}</strong></div>
              <div className="flex justify-between text-slate-400"><span>الصيانة والوقود:</span><strong className="text-rose-400">{formatNum(fleetFinance.expenses)}</strong></div>
              <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-800"><span>الصافي:</span><strong className="text-emerald-400">{formatNum(fleetFinance.net)} د.ع</strong></div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Building className="w-4 h-4 text-purple-400" /> العقارات والاستثمار
              </h3>
              <span className="text-[10px] text-purple-400 font-mono font-bold">{realEstateFinance.soldCount} مباعة</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400"><span>إجمالي المبيعات:</span><strong className="text-emerald-400">{formatNum(realEstateFinance.revenue)}</strong></div>
              <div className="flex justify-between text-slate-400"><span>إجمالي الوحدات:</span><strong className="text-slate-200">{realEstateFinance.unitsCount} وحدة</strong></div>
              <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-800"><span>المحصل:</span><strong className="text-purple-400">{formatNum(realEstateFinance.revenue)} د.ع</strong></div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <HardHat className="w-4 h-4 text-amber-400" /> المقاولات
              </h3>
              <span className="text-[10px] text-amber-400 font-mono font-bold">{projects.length} مشاريع</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400"><span>المقبوض:</span><strong className="text-emerald-400">{formatNum(summary.totalProjectsReceived)}</strong></div>
              <div className="flex justify-between text-slate-400"><span>التكاليف:</span><strong className="text-rose-400">{formatNum(summary.totalProjectsCosts)}</strong></div>
              <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-800"><span>صافي السيولة:</span><strong className="text-amber-400">{formatNum(summary.totalProjectsReceived - summary.totalProjectsCosts)} د.ع</strong></div>
            </div>
          </div>
        </div>

        {/* المخططات البيانية البصرية */}
        <div className="max-w-7xl mx-auto mt-8 space-y-6 print:hidden">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-sky-400" /> التحليلات البصرية والمقارنات البيانية للشركة
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">مقارنة أداء المشاريع، توزيع الإيرادات والمصروفات، ومسار السيولة النقدية</p>
            </div>
            <span className="text-xs bg-slate-900 border border-slate-800 text-sky-300 font-mono px-3 py-1 rounded-xl">
              Visual Data Hub
            </span>
          </div>

          {/* 1. المخطط العمودي */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-amber-400" /> المقارنة العمودية للمشاريع (قيمة العقد vs المقبوض vs التكاليف)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">مقارنة مباشرة لحجم العقود المحققة ونسب الإنفاق الميداني</p>
              </div>
            </div>

            <div className="w-full h-80 pt-4" dir="ltr">
              {barChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barChartData} margin={{ top: 10, right: 10, left: 20, bottom: 25 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} tick={{ fontSize: 11 }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px', textAlign: 'right' }}
                      formatter={(val: any) => [`${formatNum(val)} د.ع`]}
                    />
                    <Legend wrapperStyle={{ paddingTop: '15px' }} />
                    <Bar dataKey="قيمة العقد" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="المقبوض الفعلي" fill="#10b981" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="التكاليف الفعلية" fill="#f43f5e" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-slate-500 py-20 text-xs">لا توجد بيانات مشاريع نشطة للفترة المحددة</p>
              )}
            </div>
          </div>

          {/* 2. المخططات الدائرية */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-xl">
              <div className="border-b border-slate-800/80 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <PieChartIcon className="w-4 h-4 text-emerald-400" /> التوزيع النسبي لإيرادات الشركة حسب القطاع
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">حصص المقاولات، النقل، التجارة، ومبيعات العقارات</p>
              </div>

              <div className="w-full h-72" dir="ltr">
                {revenuePieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={revenuePieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={65}
                        outerRadius={95}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {revenuePieData.map((_, index) => (
                          <Cell key={`cell-rev-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px', textAlign: 'right' }}
                        formatter={(val: any) => [`${formatNum(val)} د.ع`]}
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-center text-slate-500 py-20 text-xs">لا توجد إيرادات مسجلة للفترة</p>
                )}
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-xl">
              <div className="border-b border-slate-800/80 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <PieChartIcon className="w-4 h-4 text-rose-400" /> التوزيع النسبي لهيكل التكاليف والمصروفات
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">مقارنة نفقات المشاريع بالتشغيل والمخزن والرواتب</p>
              </div>

              <div className="w-full h-72" dir="ltr">
                {expensesPieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={expensesPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={65}
                        outerRadius={95}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {expensesPieData.map((_, index) => (
                          <Cell key={`cell-exp-${index}`} fill={['#f43f5e', '#f59e0b', '#38bdf8', '#a855f7'][index % 4]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px', textAlign: 'right' }}
                        formatter={(val: any) => [`${formatNum(val)} د.ع`]}
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-center text-slate-500 py-20 text-xs">لا توجد تكاليف مسجلة للفترة</p>
                )}
              </div>
            </div>
          </div>

          {/* 3. المخطط الخطي / المساحي */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-sky-400" /> المخطط الانسيابي للمقبوضات والتكاليف وصافي السيولة
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">رسم مساحي يوضح توازن التدفقات النقدية وهوامش الأرباح</p>
              </div>
            </div>

            <div className="w-full h-72 pt-4" dir="ltr">
              {trendAreaData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendAreaData} margin={{ top: 10, right: 10, left: 20, bottom: 20 }}>
                    <defs>
                      <linearGradient id="colorRec" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorNet" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} tick={{ fontSize: 11 }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px', textAlign: 'right' }}
                      formatter={(val: any) => [`${formatNum(val)} د.ع`]}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="المقبوض" stroke="#10b981" fillOpacity={1} fill="url(#colorRec)" strokeWidth={2} />
                    <Area type="monotone" dataKey="التكلفة" stroke="#f43f5e" fillOpacity={1} fill="url(#colorExp)" strokeWidth={2} />
                    <Area type="monotone" dataKey="صافي السيولة" stroke="#38bdf8" fillOpacity={1} fill="url(#colorNet)" strokeWidth={2.5} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-slate-500 py-20 text-xs">لا توجد بيانات متاحة لعرض المخطط</p>
              )}
            </div>
          </div>
        </div>

        {/* كروت بطاقات المشاريع */}
        <div className="max-w-7xl mx-auto mt-8 space-y-6 print:hidden">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-amber-400" /> بطاقات التحليل التوازني للمشاريع النشطة بالفترة
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">مقارنة قيم العقود، والمقبوض الفعلي، ومصروفات المواد، ومعدل استنزاف الميزانية</p>
            </div>
            <span className="text-xs text-slate-400 font-mono bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl">
              المشاريع: {projects.length}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((proj: any) => {
              const contractVal = Number(proj.contract_value) || 0;
              const rate = Number(proj.completion_rate) || 0;
              const projExpenses = Number(proj.actualExpenses) || 0;
              const projReceived = Number(proj.actualReceived) || 0;
              const burnRate = contractVal > 0 ? Math.min(100, Math.round((projExpenses / contractVal) * 100)) : 0;
              const collectionRate = contractVal > 0 ? Math.min(100, Math.round((projReceived / contractVal) * 100)) : 0;
              const netCash = projReceived - projExpenses;

              return (
                <div key={proj.project_id} className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 hover:border-slate-700 transition shadow-xl">
                  <div className="flex items-start justify-between border-b border-slate-800/80 pb-3">
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                        <HardHat className="w-4 h-4 text-amber-400" /> {proj.project_name}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">العميل: <strong className="text-slate-200">{proj.client_name}</strong></p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-sky-500/10 text-sky-400 border border-sky-500/30">
                      إنجاز: {rate}%
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-400 font-sans block">قيمة العقد</span>
                      <span className="font-bold text-amber-400 text-sm">{formatNum(contractVal)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-sans block">المقبوض بالفترة</span>
                      <span className="font-bold text-emerald-400 text-sm">{formatNum(projReceived)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-sans block">المصروف بالفترة</span>
                      <span className="font-bold text-rose-400 text-sm">{formatNum(projExpenses)}</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1 font-mono">
                        <span className="text-slate-400">معدل استنزاف الميزانية</span>
                        <span className={burnRate > 80 ? 'text-rose-400 font-bold' : 'text-amber-400 font-bold'}>{burnRate}%</span>
                      </div>
                      <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                        <div className={`h-full transition-all duration-500 ${burnRate > 80 ? 'bg-rose-500' : 'bg-amber-500'}`} style={{ width: `${burnRate}%` }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1 font-mono">
                        <span className="text-slate-400">معدل التحصيل من العميل</span>
                        <span className="text-emerald-400 font-bold">{collectionRate}%</span>
                      </div>
                      <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                        <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: `${collectionRate}%` }}></div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400 font-sans">صافي السيولة النقدية للمشروع:</span>
                    <span className={`font-black text-sm ${netCash >= 0 ? 'text-sky-400' : 'text-rose-400'}`}>
                      {formatNum(netCash)} د.ع
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* تقرير الطباعة الرسمي A4 */}
        <div className="w-full max-w-5xl mx-auto bg-white text-slate-900 rounded-3xl p-8 md:p-10 border border-slate-200 shadow-2xl mt-10 print:border-none print:shadow-none print:p-0 print:m-0 space-y-6">
          <div className="flex justify-between items-center border-b-2 border-slate-900 pb-5">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 relative flex items-center justify-center p-1 bg-slate-50 rounded-2xl border border-slate-200">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/logo.png" alt="شركة البرج المتألق" className="max-h-full max-w-full object-contain" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-slate-950">شركة البرج المتألق</h1>
                <p className="text-xs text-slate-600 font-bold mt-0.5">قائمة الدخل المركزية والتقارير المالية الشاملة لجميع القطاعات</p>
                <p className="text-[11px] text-slate-500 font-mono mt-0.5">النجف الأشرف - حي الفرات | 07868006699</p>
              </div>
            </div>
            <div className="text-left flex flex-col items-end">
              <div className="border-2 border-slate-900 px-4 py-1.5 font-black text-xs uppercase tracking-wider bg-sky-500 text-slate-950 rounded-xl">
                التقرير المالي التنفيذي الموحد
              </div>
              <p className="text-[11px] font-mono mt-2 text-slate-600">تاريخ الطباعة: <span className="font-bold text-slate-950">{new Date().toISOString().split('T')[0]}</span></p>
              <p className="text-[10px] font-mono text-slate-500 mt-0.5">الفترة: {startDate || 'منذ التأسيس'} إلى {endDate || 'اليوم'}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 bg-slate-50 border border-slate-200 p-4 rounded-2xl text-xs font-mono text-center">
            <div className="p-2 bg-white rounded-xl border border-slate-100">
              <span className="text-slate-500 block text-[10px] font-sans">إجمالي الإيرادات المجمعة</span>
              <span className="text-base font-black text-emerald-600">{formatNum(summary.grandTotalRevenue)} د.ع</span>
            </div>
            <div className="p-2 bg-white rounded-xl border border-slate-100">
              <span className="text-slate-500 block text-[10px] font-sans">إجمالي المصروفات والتشغيل</span>
              <span className="text-base font-black text-rose-600">{formatNum(summary.grandTotalExpenses)} د.ع</span>
            </div>
            <div className="p-2 bg-white rounded-xl border border-slate-100">
              <span className="text-slate-500 block text-[10px] font-sans">صافي أرباح الشركة العام</span>
              <span className="text-base font-black text-sky-700">{formatNum(summary.grandNetProfit)} د.ع</span>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-black text-xs text-slate-900">ملخص الأداء المالي حسب القطاعات والوحدات التشغيلية:</h3>
            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <table className="w-full text-xs text-right font-mono">
                <thead className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                  <tr>
                    <th className="p-3">القطاع / الوحدة التشغيلية</th>
                    <th className="p-3">الإيراد / المقبوض</th>
                    <th className="p-3">المصروف والتكاليف</th>
                    <th className="p-3">الحالة / البيان</th>
                    <th className="p-3 text-left">السيولة / الربح الصافي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[11px]">
                  <tr>
                    <td className="p-3 font-bold font-sans text-slate-950">قطاع التجارة العامة والمخزن المركزي</td>
                    <td className="p-3 text-emerald-600">{formatNum(tradeFinance.salesRevenue)} د.ع</td>
                    <td className="p-3 text-rose-600">{formatNum(tradeFinance.purchasesExpenses)} د.ع</td>
                    <td className="p-3 text-slate-500 font-sans">مبيعات واستيراد</td>
                    <td className="p-3 text-left font-black text-sky-700">{formatNum(tradeFinance.netProfit)} د.ع</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold font-sans text-slate-950">قطاع النقل العام واللوجستيات (الأسطول)</td>
                    <td className="p-3 text-emerald-600">{formatNum(fleetFinance.revenue)} د.ع</td>
                    <td className="p-3 text-rose-600">{formatNum(fleetFinance.expenses)} د.ع</td>
                    <td className="p-3 text-slate-500 font-sans">أجور نقل وصيانة</td>
                    <td className="p-3 text-left font-black text-sky-700">{formatNum(fleetFinance.net)} د.ع</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold font-sans text-slate-950">قطاع العقارات والاستثمار</td>
                    <td className="p-3 text-emerald-600">{formatNum(realEstateFinance.revenue)} د.ع</td>
                    <td className="p-3 text-rose-600">0 د.ع</td>
                    <td className="p-3 text-slate-500 font-sans">{realEstateFinance.soldCount} وحدات مباعة</td>
                    <td className="p-3 text-left font-black text-sky-700">{formatNum(realEstateFinance.revenue)} د.ع</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold font-sans text-slate-950">الموارد البشرية وكتلة الرواتب والأجور</td>
                    <td className="p-3 text-slate-400">---</td>
                    <td className="p-3 text-rose-600">{formatNum(hrFinance.totalSalaries)} د.ع</td>
                    <td className="p-3 text-slate-500 font-sans">{hrFinance.count} موظف نشط</td>
                    <td className="p-3 text-left font-black text-rose-700">-{formatNum(hrFinance.totalSalaries)} د.ع</td>
                  </tr>
                  {projects.map((pr: any) => (
                    <tr key={pr.project_id}>
                      <td className="p-3 font-bold font-sans text-slate-950">{pr.project_name}</td>
                      <td className="p-3 text-emerald-600">{formatNum(pr.actualReceived)} د.ع</td>
                      <td className="p-3 text-rose-600">{formatNum(pr.actualExpenses)} د.ع</td>
                      <td className="p-3 text-sky-700 font-sans">إنجاز: {pr.completion_rate}%</td>
                      <td className="p-3 text-left font-black text-slate-900">{formatNum(pr.netCash)} د.ع</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-8 pt-12 text-center border-t border-slate-200">
            <div>
              <p className="font-bold text-xs text-slate-700">مدير الحسابات والمالية</p>
              <div className="border-b border-dashed border-slate-400 w-36 mx-auto mt-10"></div>
            </div>
            <div>
              <p className="font-bold text-xs text-slate-700">المدقق المالي الداخلي</p>
              <div className="border-b border-dashed border-slate-400 w-36 mx-auto mt-10"></div>
            </div>
            <div>
              <p className="font-bold text-xs text-slate-700">المدير التنفيذي للشركة</p>
              <div className="border-b border-dashed border-slate-400 w-36 mx-auto mt-10"></div>
            </div>
          </div>
        </div>

      </div>
    </AuthGuard>
  );
}