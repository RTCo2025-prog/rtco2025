'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Building2, 
  LogIn, 
  User, 
  Lock, 
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'LOGIN',
          username,
          password
        }),
      });

      const text = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error('فشل قراءة رد السيرفر');
      }

      if (!res.ok || !data.success) {
        setError(data.error || 'اسم المستخدم أو كلمة المرور غير صحيحة');
        return;
      }

      localStorage.setItem('erp_user', JSON.stringify(data.user));
      router.push('/');
    } catch (err: any) {
      setError(err.message || 'حدث خطأ في الاتصال بالخادم');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        
        {/* الترويسة والشعار */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="bg-amber-500 p-3 rounded-2xl text-slate-950 shadow-lg shadow-amber-500/20 mb-3">
            <Building2 className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-black text-white">شركة البرج المتألق</h1>
          <p className="text-xs text-slate-400 mt-1">منظومة الإدارة المركزية والمشاريع (ERP)</p>
          <div className="flex items-center gap-1.5 mt-3 text-[11px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>بوابة موظفي ومسؤولي الشركة</span>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-5 rounded-xl text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1 font-semibold">اسم المستخدم (Username) *</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              <input
                type="text"
                required
                dir="ltr"
                placeholder="eng_amer"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pr-9 pl-3 py-2.5 text-white outline-none focus:border-amber-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-semibold">كلمة المرور *</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pr-9 pl-3 py-2.5 text-white outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl transition text-xs shadow-lg shadow-amber-500/20 mt-2 flex items-center justify-center gap-1.5"
          >
            <LogIn className="w-4 h-4" />
            {loading ? 'جاري التحقق...' : 'دخول إلى المنظومة'}
          </button>
        </form>

        <p className="text-[11px] text-slate-500 text-center mt-6">
          إنشاء وتفعيل الحسابات يتم حصراً بواسطة الإدارة العليا للشركة.
        </p>
      </div>
    </div>
  );
}