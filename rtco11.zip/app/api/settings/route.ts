import { NextResponse } from 'next/server';
import { query } from '@/lib/db';

// التأكد من وجود الجدول وحقول الترويسة والشعار
async function initSettingsTable() {
  await query(`
    CREATE TABLE IF NOT EXISTS company_settings (
      id SERIAL PRIMARY KEY,
      company_name VARCHAR(255) DEFAULT 'شركة البرج المتألق',
      tagline VARCHAR(255) DEFAULT 'للمقاولات العامة والاستثمارات العقارية والتجارة العامة والنقل العام',
      phone_primary VARCHAR(50) DEFAULT '',
      phone_secondary VARCHAR(50) DEFAULT '',
      email VARCHAR(100) DEFAULT '',
      website VARCHAR(100) DEFAULT '',
      address VARCHAR(255) DEFAULT 'العراق - النجف الأشرف - حي الفرات',
      logo_url TEXT DEFAULT '',
      letterhead_url TEXT DEFAULT '',
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // إضافة الأعمدة إن كانت غير موجودة في جدول سابق
  await query(`
    DO $$ 
    BEGIN 
      BEGIN
        ALTER TABLE company_settings ADD COLUMN logo_url TEXT DEFAULT '';
      EXCEPTION WHEN duplicate_column THEN END;
      BEGIN
        ALTER TABLE company_settings ADD COLUMN letterhead_url TEXT DEFAULT '';
      EXCEPTION WHEN duplicate_column THEN END;
    END $$;
  `);

  const check = await query(`SELECT id FROM company_settings WHERE id = 1`);
  if (check.rows.length === 0) {
    await query(`
      INSERT INTO company_settings (id, company_name, address, tagline)
      VALUES (1, 'شركة البرج المتألق', 'العراق - النجف الأشرف - حي الفرات', 'للمقاولات العامة والاستثمارات العقارية والتجارة العامة والنقل العام')
    `);
  }
}

export async function GET() {
  try {
    await initSettingsTable();
    const res = await query(`SELECT * FROM company_settings WHERE id = 1`);
    return NextResponse.json({ success: true, settings: res.rows[0] });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await initSettingsTable();
    const body = await req.json();
    const { 
      company_name, 
      tagline, 
      phone_primary, 
      phone_secondary, 
      email, 
      website, 
      address, 
      logo_url, 
      letterhead_url 
    } = body;

    await query(`
      UPDATE company_settings 
      SET company_name = $1, 
          tagline = $2, 
          phone_primary = $3, 
          phone_secondary = $4, 
          email = $5, 
          website = $6, 
          address = $7,
          logo_url = $8,
          letterhead_url = $9,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
    `, [company_name, tagline, phone_primary, phone_secondary, email, website, address, logo_url, letterhead_url]);

    return NextResponse.json({ success: true, message: 'تم تحديث بيانات وهوية الشركة بنجاح' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}