import { Pool } from 'pg';

let pool: Pool;

function getPool(): Pool {
  if (!pool) {
    const connectionString = process.env.DATABASE_URL;

    if (!connectionString) {
      throw new Error('DATABASE_URL is not set in environment variables');
    }

    pool = new Pool({
      connectionString,
      ssl: {
        rejectUnauthorized: false // يسمح بالاتصال الآمن المشفر في اللوكال وعلى سيرفرات الاستضافة
      },
      max: 10, // الحد الأقصى للموصلات في التجمع
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    });

    pool.on('error', (err) => {
      console.error('Unexpected error on idle database client', err);
    });
  }

  return pool;
}

export async function query(text: string, params?: any[]) {
  const dbPool = getPool();
  const client = await dbPool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}

export default getPool;